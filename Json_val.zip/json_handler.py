import avro.schema
from avro.datafile import DataFileReader,DataFileWriter
from avro.io import  DatumWriter,DatumReader


schema=avro.schema.Ptiarse(open("json _schema1.avsc").read())

sch